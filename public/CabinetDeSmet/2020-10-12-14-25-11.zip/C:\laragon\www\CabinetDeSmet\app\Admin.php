<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

// hérite de la classe User de voyager
class Admin extends \TCG\Voyager\Models\User
{
    
}
