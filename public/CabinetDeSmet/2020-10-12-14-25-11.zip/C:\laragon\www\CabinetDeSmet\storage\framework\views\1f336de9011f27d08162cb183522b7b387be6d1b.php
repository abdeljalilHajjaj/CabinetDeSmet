<?php $__env->startSection('content'); ?>

        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>
    <div class="table-responsive  w-100 float-right"> 
        <table class="table table-striped table-inverse" id="myTable">
            <thead class="thead-inverse">
                <tr>
                    
                    <th>NISS</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Adresse</th>
                    <th>Date de naissance</th>
                    <th>Sexe</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $patients->where('statut','actif'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($patient->rdv->where('statut','absent')->count() >10): ?>
                    <tr style="color:violet">
                      
                        <td><a href="dossierMed/<?php echo e($patient->id); ?> "><?php echo e($patient->rn); ?></a></td>
                        <td><?php echo e($patient->nom); ?></td>
                        <td><?php echo e($patient->prenom); ?></td>
                        <td><?php echo e($patient->adresse); ?></td>
                        <td><?php echo e($patient->dateFormat()); ?></td>
                        <td><?php echo e($patient->sexe); ?></td>
                    </tr>
                    <?php else: ?>
                  

                    <tr>
                
                        <td><a href="dossierMed/<?php echo e($patient->id); ?> "><?php echo e($patient->rn); ?></a></td>
                        <td><?php echo e($patient->nom); ?></td>
                        <td><?php echo e($patient->prenom); ?></td>
                        <td><?php echo e($patient->adresse); ?></td>
                        <td><?php echo e($patient->dateFormat()); ?></td>
                        <td><?php echo e($patient->sexe); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </table>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
$(document).ready( function () {
    $('#myTable').DataTable({
        "language": {
            "url": "<?php echo e(asset('frDataTables.txt')); ?> "
        }
    });
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/listPatient.blade.php ENDPATH**/ ?>