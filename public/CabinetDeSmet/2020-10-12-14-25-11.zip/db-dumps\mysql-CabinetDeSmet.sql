
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`),
  KEY `admins_role_id_foreign` (`role_id`),
  CONSTRAINT `admins_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,1,'abdel','admin@gmail.com','users/default.png','$2y$10$YgR169SKKR7af6HtOtXfVuDJ1zr0oymzYjgj8/iiSioPG478ULsDS',NULL,NULL,NULL,NULL),(3,1,'admin','CabDeSmetadmin@gmail.com','users/default.png','$2y$10$1Fc7UaTUTeYUS1/VGaVOO.fgl7.6vMa7mS4Aul/Yq14MULwhaf1Je',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analyses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeAnalyse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lienFichier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `analyses_inami_med_foreign` (`inami_med`),
  KEY `analyses_patient_id_index` (`patient_id`),
  CONSTRAINT `analyses_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `analyses_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `analyses` WRITE;
/*!40000 ALTER TABLE `analyses` DISABLE KEYS */;
/*!40000 ALTER TABLE `analyses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `antecedents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antecedents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `antecedents_inami_med_foreign` (`inami_med`),
  KEY `antecedents_patient_id_index` (`patient_id`),
  CONSTRAINT `antecedents_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `antecedents_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `antecedents` WRITE;
/*!40000 ALTER TABLE `antecedents` DISABLE KEYS */;
INSERT INTO `antecedents` VALUES (1,'Monsieur a subi une opération du genoux en décembre 2014',1,'85747865','actif','2020-08-08 13:28:07','2020-08-08 13:28:07');
/*!40000 ALTER TABLE `antecedents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `motif` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `objectif` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectif` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `planSuivi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `poids` double(8,2) NOT NULL,
  `taille` int(11) NOT NULL,
  `pa_sys` double(8,2) NOT NULL,
  `pa_dia` double(8,2) NOT NULL,
  `rythme_card` double(8,2) NOT NULL,
  `temperature` double(8,2) NOT NULL,
  `saturation_oxygene` int(11) NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consultation_inami_med_foreign` (`inami_med`),
  KEY `consultation_patient_id_index` (`patient_id`),
  CONSTRAINT `consultation_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `consultation_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `consultation` WRITE;
/*!40000 ALTER TABLE `consultation` DISABLE KEYS */;
INSERT INTO `consultation` VALUES (1,'45225','test','test','test',85.00,175,12.00,8.00,85.00,37.00,85,1,'85951252','inactif','2020-07-23 12:19:55','2020-07-23 12:26:36'),(2,'Monsieur est venu car il souffre d\'une douleur au genou gauche','Réaction lors de la palpation du genou en question','Le patient indique qu\'il ressent des picotements lorsqu\'il effectue des tâches lourdes','Proposition d\'un rendez-vous auprès d\'un kyné',85.00,175,15.00,12.00,85.00,35.00,75,1,'85747865','actif','2020-08-08 13:30:18','2020-08-08 13:30:18'),(4,'douleur au bras droit','Le patient montre des signes de douleurs lorsque une pression est effectuée','Le patient décrit de forte douleur lorsqu\'il dort et se réveille souvent la nuit','Propose un rendez-vous chez le kiné pour suivi',75.00,174,12.00,10.00,85.00,36.00,85,10,'85747865','actif','2020-10-09 16:33:27','2020-10-09 16:33:27');
/*!40000 ALTER TABLE `consultation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `data_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_type_id` int(10) unsigned NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `data_rows_data_type_id_foreign` (`data_type_id`),
  CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `data_rows` WRITE;
/*!40000 ALTER TABLE `data_rows` DISABLE KEYS */;
INSERT INTO `data_rows` VALUES (1,1,'id','number','ID',1,0,0,0,0,0,NULL,1),(2,1,'name','text','Nom',1,1,1,1,1,1,NULL,2),(3,1,'email','text','Email',1,1,1,1,1,1,NULL,3),(4,1,'password','password','Mot de passe',1,0,0,1,1,0,NULL,4),(5,1,'remember_token','text','Token de rappel',0,0,0,0,0,0,NULL,5),(6,1,'created_at','timestamp','Créé le',0,1,1,0,0,0,NULL,6),(7,1,'updated_at','timestamp','Mis à jour le',0,0,0,0,0,0,NULL,7),(8,1,'avatar','image','Avatar',0,1,1,1,1,1,NULL,8),(9,1,'user_belongsto_role_relationship','relationship','Rôle',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":0}',10),(10,1,'user_belongstomany_role_relationship','relationship','Roles',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}',11),(11,1,'settings','hidden','Settings',0,0,0,0,0,0,NULL,12),(12,2,'id','number','ID',1,0,0,0,0,0,NULL,1),(13,2,'name','text','Nom',1,1,1,1,1,1,NULL,2),(14,2,'created_at','timestamp','Créé le',0,0,0,0,0,0,NULL,3),(15,2,'updated_at','timestamp','Mis à jour le',0,0,0,0,0,0,NULL,4),(16,3,'id','number','ID',1,0,0,0,0,0,NULL,1),(17,3,'name','text','Nom',1,1,1,1,1,1,NULL,2),(18,3,'created_at','timestamp','Créé le',0,0,0,0,0,0,NULL,3),(19,3,'updated_at','timestamp','Mis à jour le',0,0,0,0,0,0,NULL,4),(20,3,'display_name','text','Nom d\'affichage',1,1,1,1,1,1,NULL,5),(21,1,'role_id','text','Rôle',1,1,1,1,1,1,NULL,9),(22,4,'id','text','Id',1,0,0,0,0,0,'{}',1),(23,4,'nom','text','Nom',1,1,1,1,1,1,'{}',2),(24,4,'prenom','text','Prenom',1,1,1,1,1,1,'{}',3),(25,4,'adresse','text','Adresse',1,1,1,1,1,1,'{}',4),(26,4,'tel','text','Tel',1,1,1,1,1,1,'{}',5),(27,4,'email','text','Email',1,1,1,1,1,1,'{}',6),(28,4,'password','password','Password',1,1,1,1,1,1,'{}',7),(29,4,'statut','select_dropdown','Statut',1,1,1,1,1,1,'{\"options\":{\"actif\":\"actif\",\"inactif\":\"inactif\"}}',8),(30,4,'created_at','timestamp','Created At',0,1,1,1,0,1,'{}',9),(31,4,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'{}',10),(32,5,'id','text','Id',1,0,0,0,0,0,'{}',1),(33,5,'nom','text','Nom',1,1,1,1,1,1,'{}',2),(34,5,'prenom','text','Prenom',1,1,1,1,1,1,'{}',3),(35,5,'adresse','text','Adresse',1,1,1,1,1,1,'{}',4),(36,5,'tel','text','Tel',1,1,1,1,1,1,'{}',5),(37,5,'inami','text','Inami',1,1,1,1,1,1,'{}',6),(38,5,'email','text','Email',1,1,1,1,1,1,'{}',7),(39,5,'password','password','Password',1,1,1,1,1,1,'{}',8),(40,5,'statut','select_dropdown','Statut',1,1,1,1,1,1,'{\"options\":{\"actif\":\"actif\",\"inactif\":\"inactif\"}}',9),(41,5,'gCal_id','text','GCal Id',1,1,1,1,1,1,'{}',10),(42,5,'created_at','timestamp','Created At',0,1,1,1,0,1,'{}',11),(43,5,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'{}',12),(44,6,'id','text','Id',1,0,0,0,0,0,'{}',1),(45,6,'nomMedic','text','NomMedic',1,1,1,1,1,1,'{}',2),(46,6,'posologie','text','Posologie',1,1,1,1,1,1,'{}',3),(47,6,'statut','select_dropdown','Statut',1,1,1,1,1,1,'{\"options\":{\"actif\":\"actif\",\"inactif\":\"inactif\"}}',4),(48,6,'created_at','timestamp','Created At',0,1,1,1,0,1,'{}',5),(49,6,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'{}',6),(50,7,'id','text','Id',1,0,0,0,0,0,'{}',1),(51,7,'nom','text','Nom',1,1,1,1,1,1,'{}',2),(52,7,'prenom','text','Prenom',1,1,1,1,1,1,'{}',3),(53,7,'adresse','text','Adresse',1,1,1,1,1,1,'{}',4),(54,7,'tel','text','Tel',1,1,1,1,1,1,'{}',5),(55,7,'sexe','text','Sexe',1,1,1,1,1,1,'{}',6),(56,7,'date_naiss','date','Date Naiss',1,1,1,1,1,1,'{}',7),(57,7,'rn','text','Rn',1,1,1,1,1,1,'{}',8),(58,7,'email','text','Email',1,1,1,1,1,1,'{}',9),(59,7,'password','password','Password',1,1,1,1,1,1,'{}',10),(60,7,'statut','select_dropdown','Statut',1,1,1,1,1,1,'{\"options\":{\"actif\":\"actif\",\"inactif\":\"inactif\"}}',11),(61,7,'created_at','timestamp','Created At',0,1,1,1,0,1,'{}',12),(62,7,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'{}',13);
/*!40000 ALTER TABLE `data_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT '0',
  `server_side` tinyint(4) NOT NULL DEFAULT '0',
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `data_types_name_unique` (`name`),
  UNIQUE KEY `data_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `data_types` WRITE;
/*!40000 ALTER TABLE `data_types` DISABLE KEYS */;
INSERT INTO `data_types` VALUES (1,'users','users','Utilisateur','Utilisateurs','voyager-person','TCG\\Voyager\\Models\\User','TCG\\Voyager\\Policies\\UserPolicy','TCG\\Voyager\\Http\\Controllers\\VoyagerUserController','',1,0,NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(2,'menus','menus','Menu','Menus','voyager-list','TCG\\Voyager\\Models\\Menu',NULL,'','',1,0,NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(3,'roles','roles','Rôle','Rôles','voyager-lock','TCG\\Voyager\\Models\\Role',NULL,'TCG\\Voyager\\Http\\Controllers\\VoyagerRoleController','',1,0,NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(4,'secretaires','secretaires','Secretaire','Secretaires',NULL,'App\\Secretaire',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}','2020-07-23 12:01:14','2020-07-23 12:01:14'),(5,'medecins','medecins','Medecin','Medecins',NULL,'App\\Medecin',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}','2020-07-23 12:02:29','2020-07-23 12:02:29'),(6,'medicaments','medicaments','Medicament','Medicaments',NULL,'App\\Medicament',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}','2020-07-23 12:02:51','2020-07-23 12:02:51'),(7,'patients','patients','Patient','Patients',NULL,'App\\Patient',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}','2020-07-23 12:03:42','2020-08-08 13:22:24');
/*!40000 ALTER TABLE `data_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `disponibilites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disponibilites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateDebut` timestamp NOT NULL,
  `dateFin` timestamp NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gEventId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `disponibilites_inami_med_foreign` (`inami_med`),
  CONSTRAINT `disponibilites_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `disponibilites` WRITE;
/*!40000 ALTER TABLE `disponibilites` DISABLE KEYS */;
/*!40000 ALTER TABLE `disponibilites` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dossiermed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dossiermed` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dossiermed_patient_id_index` (`patient_id`),
  CONSTRAINT `dossiermed_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dossiermed` WRITE;
/*!40000 ALTER TABLE `dossiermed` DISABLE KEYS */;
INSERT INTO `dossiermed` VALUES (1,1,'2020-07-23 12:13:51','2020-07-23 12:13:51'),(2,2,'2020-08-08 13:27:32','2020-08-08 13:27:32'),(3,6,'2020-10-08 13:19:07','2020-10-08 13:19:07'),(4,10,'2020-10-09 16:31:14','2020-10-09 16:31:14');
/*!40000 ALTER TABLE `dossiermed` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facteur_risques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facteur_risques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facteur_risques_inami_med_foreign` (`inami_med`),
  KEY `facteur_risques_patient_id_index` (`patient_id`),
  CONSTRAINT `facteur_risques_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `facteur_risques_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facteur_risques` WRITE;
/*!40000 ALTER TABLE `facteur_risques` DISABLE KEYS */;
/*!40000 ALTER TABLE `facteur_risques` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medecins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medecins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inami` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gCal_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `medecins_inami_unique` (`inami`),
  UNIQUE KEY `medecins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medecins` WRITE;
/*!40000 ALTER TABLE `medecins` DISABLE KEYS */;
INSERT INTO `medecins` VALUES (1,'Du pont','Fred','rue haute 344 1000 bruxelles','0487798547','85747865','drh@hotmail.com','$2y$10$rvOd41FT6ntnCFr8g9zQou98L5eFoHznMcGYSq9khS1ac6dirM1j2','actif','cabinettest12@gmail.com','2020-07-23 12:06:17','2020-07-23 12:06:17'),(2,'Karin','Matou','Rue de la sambre 6 1080 Molenbeek-Saint-Jean','0412658578','85951252','Karin.Matou@gmail.com','$2y$10$9q8BvN1vNNyyj0UVvq6ft./1jxrkMYjqihvHJTGjtrBH8wjX/1ufy','actif','td4rq4kgmbukgat5dmi3ss0lg4@group.calendar.google.com','2020-07-23 12:07:23','2020-07-23 12:07:23');
/*!40000 ALTER TABLE `medecins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicaments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codeMedic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomMedic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `posologie` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medicaments` WRITE;
/*!40000 ALTER TABLE `medicaments` DISABLE KEYS */;
INSERT INTO `medicaments` VALUES (1,'D875','Dafalgan 400','2 x par jour / 2 semaines','actif','2020-07-23 12:28:00','2020-07-23 12:30:24'),(2,'I4254','ibuprofen 400','3 x par jour / 2 semaines','actif','2020-07-23 12:29:00','2020-07-23 12:30:15'),(3,'X6585','xanax Rd','2 x par jour / 5 semaines','actif','2020-07-23 12:29:24','2020-07-23 12:29:24'),(4,'I5255','ibuprofen 500','2 x par jour / 2 semaines','actif','2020-07-23 12:29:00','2020-07-23 12:30:33');
/*!40000 ALTER TABLE `medicaments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,1,'Tableau de bord','','_self','voyager-boat',NULL,NULL,1,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.dashboard',NULL),(2,1,'Médiathèque','','_self','voyager-images',NULL,NULL,5,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.media.index',NULL),(3,1,'Utilisateurs','','_self','voyager-person',NULL,NULL,3,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.users.index',NULL),(4,1,'Rôles','','_self','voyager-lock',NULL,NULL,2,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.roles.index',NULL),(5,1,'Outils','','_self','voyager-tools',NULL,NULL,9,'2020-07-23 11:54:28','2020-07-23 11:54:28',NULL,NULL),(6,1,'Créateur de menus','','_self','voyager-list',NULL,5,10,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.menus.index',NULL),(7,1,'Base de données','','_self','voyager-data',NULL,5,11,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.database.index',NULL),(8,1,'Compass','','_self','voyager-compass',NULL,5,12,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.compass.index',NULL),(9,1,'BREAD','','_self','voyager-bread',NULL,5,13,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.bread.index',NULL),(10,1,'Paramètres','','_self','voyager-settings',NULL,NULL,14,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.settings.index',NULL),(11,1,'Hooks','','_self','voyager-hook',NULL,NULL,13,'2020-07-23 11:54:28','2020-07-23 11:54:28','voyager.hooks',NULL),(12,1,'Secretaires','','_self',NULL,NULL,NULL,15,'2020-07-23 12:01:14','2020-07-23 12:01:14','voyager.secretaires.index',NULL),(13,1,'Medecins','','_self',NULL,NULL,NULL,16,'2020-07-23 12:02:29','2020-07-23 12:02:29','voyager.medecins.index',NULL),(14,1,'Medicaments','','_self',NULL,NULL,NULL,17,'2020-07-23 12:02:51','2020-07-23 12:02:51','voyager.medicaments.index',NULL),(15,1,'Patients','','_self',NULL,NULL,NULL,18,'2020-07-23 12:03:42','2020-07-23 12:03:42','voyager.patients.index',NULL);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'admin','2020-07-23 11:54:28','2020-07-23 11:54:28');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_01_000000_add_voyager_user_fields',1),(4,'2016_01_01_000000_create_data_types_table',1),(5,'2016_05_19_173453_create_menu_table',1),(6,'2016_10_21_190000_create_roles_table',1),(7,'2016_10_21_190000_create_settings_table',1),(8,'2016_11_30_135954_create_permission_table',1),(9,'2016_11_30_141208_create_permission_role_table',1),(10,'2016_12_26_201236_data_types__add__server_side',1),(11,'2017_01_13_000000_add_route_to_menu_items_table',1),(12,'2017_01_14_005015_create_translations_table',1),(13,'2017_01_15_000000_make_table_name_nullable_in_permissions_table',1),(14,'2017_03_06_000000_add_controller_to_data_types_table',1),(15,'2017_04_21_000000_add_order_to_data_rows_table',1),(16,'2017_07_05_210000_add_policyname_to_data_types_table',1),(17,'2017_08_05_000000_add_group_to_settings_table',1),(18,'2017_11_26_013050_add_user_role_relationship',1),(19,'2017_11_26_015000_create_user_roles_table',1),(20,'2018_03_11_000000_add_user_settings',1),(21,'2018_03_14_000000_add_details_to_data_types_table',1),(22,'2018_03_16_000000_make_settings_value_nullable',1),(23,'2019_08_19_000000_create_failed_jobs_table',1),(24,'2020_05_20_094311_create_admins_table',1),(25,'2020_05_20_103930_create_patients_table',1),(26,'2020_05_25_080025_create_medecins_table',1),(27,'2020_05_25_080743_create_secretaires_table',1),(28,'2020_05_29_061300_create_dossier_med_table',1),(29,'2020_05_30_080401_create_antecedents_table',1),(30,'2020_06_17_125230_create_consultation_table',1),(31,'2020_06_23_195413_create_radios_table',1),(32,'2020_06_27_185843_create_rdv_table',1),(33,'2020_07_16_200815_create_disponibilites_table',1),(34,'2020_07_22_082720_create_analyses_table',1),(35,'2020_07_22_122714_create_ordonnances_table',1),(36,'2020_07_22_134258_create_medicaments_table',1),(37,'2020_07_23_130449_create_facteur_risques_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ordonnances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordonnances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `listeMedic` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ordonnances_inami_med_foreign` (`inami_med`),
  KEY `ordonnances_patient_id_index` (`patient_id`),
  CONSTRAINT `ordonnances_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `ordonnances_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ordonnances` WRITE;
/*!40000 ALTER TABLE `ordonnances` DISABLE KEYS */;
INSERT INTO `ordonnances` VALUES (1,'ibuprofen 400 : 3 x par jour / 2 semaines , Dafalgan 400 : 2 x par jour / 2 semaines',1,'85951252','actif','2020-07-23 12:31:14','2020-07-23 12:31:14'),(2,'Dafalgan 400 : 2 x par jour / 2 semaines , ibuprofen 400 : 3 x par jour / 2 semaines , xanax Rd : 2 x par jour / 5 semaines',1,'85747865','actif','2020-07-31 17:04:59','2020-07-31 17:04:59'),(3,'Dafalgan 400 : 2 x par jour / 2 semaines , ibuprofen 400 : 3 x par jour / 2 semaines',1,'85747865','actif','2020-10-08 16:12:21','2020-10-08 16:12:21'),(4,'Dafalgan 400 : 2 x par jour / 2 semaines , ibuprofen 400 : 3 x par jour / 2 semaines',10,'85747865','actif','2020-10-09 16:33:49','2020-10-09 16:33:49');
/*!40000 ALTER TABLE `ordonnances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('dragonfith@hotmail.com','$2y$10$veQd/M2axNYFEMp3FK0Qp.Aio.NxGHNusqriRDyoOKdkSKMT91dp.','2020-08-08 14:58:30');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_naiss` date NOT NULL,
  `rn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patients_rn_unique` (`rn`),
  UNIQUE KEY `patients_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Hajjaj','Abdeljalil','Rue des congrés 1030 schaerbeek','0475347479','H','1995-11-10','95111019525','dragonfith@hotmail.com','$2y$10$ZSovuSJkamRL.GcxW2vn3Oaek9nEQ.vQNKdPl9T5ZqLx.LgrvXSnq','actif','2020-07-23 11:56:44','2020-08-08 14:56:40'),(2,'Ben Attou','Safae','rue artan 58 1030 schaerbeek','0467728004','F','1996-05-03','84757487445','safae@gmail.com','$2y$10$U/7YrDJfcdGngN308.ZCKuI4BIigKTs7pDRxc9/Df0IY606iApIMC','actif','2020-08-08 13:23:09','2020-08-08 13:23:09'),(3,'John','Doe','Rue de l\'inconnu 1030 Schaerbeek','0452658578','H','1998-01-08','98121014587','drek@hotmail.fr','$2y$10$rrElokLv6Xh7vWK.uJ/X7.VnclctUsze0Gan8ao0.kGMlLO.v7Ut2','actif','2020-08-08 13:24:19','2020-08-08 13:24:19'),(4,'Mama','Prince','Rue de l\'aube 1030 Schaerbeek','0475347477','H','1985-05-16','85051674758','mama@gmail.com','$2y$10$stlvJEfT4cTbnCPgXi4kiOu1ZRe8ufh1/ekOD.EyYIXLP.SGOx.Vi','inactif','2020-08-08 13:25:35','2020-08-08 13:25:35'),(5,'Franck','Dux','Rue du pull 10 1030 Schaerbeek','0452321217','H','1954-06-25','54062517854','duxFranck@hotmail.fr','$2y$10$MsuVM6vKSLVIZe3WLjxgnuv.Noj.fEsPnHu.7zQ/xl3ahxukKAnzy','en attente','2020-08-08 15:14:26','2020-08-08 15:14:26'),(10,'Kaoutar','premamam','Rue du fort 4 1080','0467728004','H','1985-12-15','85747874574','kaouh5@outlook.fr','$2y$10$wck8p/G5rrHOiance8HI2OaqZOU94zNigO/iz7GQkCJKHFj434XYy','actif','2020-10-09 16:28:18','2020-10-09 16:29:18');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_permission_id_index` (`permission_id`),
  KEY `permission_role_role_id_index` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'browse_admin',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(2,'browse_bread',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(3,'browse_database',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(4,'browse_media',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(5,'browse_compass',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(6,'browse_menus','menus','2020-07-23 11:54:28','2020-07-23 11:54:28'),(7,'read_menus','menus','2020-07-23 11:54:28','2020-07-23 11:54:28'),(8,'edit_menus','menus','2020-07-23 11:54:28','2020-07-23 11:54:28'),(9,'add_menus','menus','2020-07-23 11:54:28','2020-07-23 11:54:28'),(10,'delete_menus','menus','2020-07-23 11:54:28','2020-07-23 11:54:28'),(11,'browse_roles','roles','2020-07-23 11:54:28','2020-07-23 11:54:28'),(12,'read_roles','roles','2020-07-23 11:54:28','2020-07-23 11:54:28'),(13,'edit_roles','roles','2020-07-23 11:54:28','2020-07-23 11:54:28'),(14,'add_roles','roles','2020-07-23 11:54:28','2020-07-23 11:54:28'),(15,'delete_roles','roles','2020-07-23 11:54:28','2020-07-23 11:54:28'),(16,'browse_users','users','2020-07-23 11:54:28','2020-07-23 11:54:28'),(17,'read_users','users','2020-07-23 11:54:28','2020-07-23 11:54:28'),(18,'edit_users','users','2020-07-23 11:54:28','2020-07-23 11:54:28'),(19,'add_users','users','2020-07-23 11:54:28','2020-07-23 11:54:28'),(20,'delete_users','users','2020-07-23 11:54:28','2020-07-23 11:54:28'),(21,'browse_settings','settings','2020-07-23 11:54:28','2020-07-23 11:54:28'),(22,'read_settings','settings','2020-07-23 11:54:28','2020-07-23 11:54:28'),(23,'edit_settings','settings','2020-07-23 11:54:28','2020-07-23 11:54:28'),(24,'add_settings','settings','2020-07-23 11:54:28','2020-07-23 11:54:28'),(25,'delete_settings','settings','2020-07-23 11:54:28','2020-07-23 11:54:28'),(26,'browse_hooks',NULL,'2020-07-23 11:54:28','2020-07-23 11:54:28'),(27,'browse_secretaires','secretaires','2020-07-23 12:01:14','2020-07-23 12:01:14'),(28,'read_secretaires','secretaires','2020-07-23 12:01:14','2020-07-23 12:01:14'),(29,'edit_secretaires','secretaires','2020-07-23 12:01:14','2020-07-23 12:01:14'),(30,'add_secretaires','secretaires','2020-07-23 12:01:14','2020-07-23 12:01:14'),(31,'delete_secretaires','secretaires','2020-07-23 12:01:14','2020-07-23 12:01:14'),(32,'browse_medecins','medecins','2020-07-23 12:02:29','2020-07-23 12:02:29'),(33,'read_medecins','medecins','2020-07-23 12:02:29','2020-07-23 12:02:29'),(34,'edit_medecins','medecins','2020-07-23 12:02:29','2020-07-23 12:02:29'),(35,'add_medecins','medecins','2020-07-23 12:02:29','2020-07-23 12:02:29'),(36,'delete_medecins','medecins','2020-07-23 12:02:29','2020-07-23 12:02:29'),(37,'browse_medicaments','medicaments','2020-07-23 12:02:51','2020-07-23 12:02:51'),(38,'read_medicaments','medicaments','2020-07-23 12:02:51','2020-07-23 12:02:51'),(39,'edit_medicaments','medicaments','2020-07-23 12:02:51','2020-07-23 12:02:51'),(40,'add_medicaments','medicaments','2020-07-23 12:02:51','2020-07-23 12:02:51'),(41,'delete_medicaments','medicaments','2020-07-23 12:02:51','2020-07-23 12:02:51'),(42,'browse_patients','patients','2020-07-23 12:03:42','2020-07-23 12:03:42'),(43,'read_patients','patients','2020-07-23 12:03:42','2020-07-23 12:03:42'),(44,'edit_patients','patients','2020-07-23 12:03:42','2020-07-23 12:03:42'),(45,'add_patients','patients','2020-07-23 12:03:42','2020-07-23 12:03:42'),(46,'delete_patients','patients','2020-07-23 12:03:42','2020-07-23 12:03:42');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `radios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lien` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `radios_inami_med_foreign` (`inami_med`),
  KEY `radios_patient_id_index` (`patient_id`),
  CONSTRAINT `radios_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `radios_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `dossiermed` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `radios` WRITE;
/*!40000 ALTER TABLE `radios` DISABLE KEYS */;
/*!40000 ALTER TABLE `radios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rdv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateRdv` timestamp NOT NULL,
  `dateFinRdv` timestamp NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `inami_med` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gEventId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rdv_inami_med_foreign` (`inami_med`),
  KEY `rdv_patient_id_index` (`patient_id`),
  CONSTRAINT `rdv_inami_med_foreign` FOREIGN KEY (`inami_med`) REFERENCES `medecins` (`inami`),
  CONSTRAINT `rdv_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rdv` WRITE;
/*!40000 ALTER TABLE `rdv` DISABLE KEYS */;
/*!40000 ALTER TABLE `rdv` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrateur','2020-07-23 11:54:28','2020-07-23 11:54:28'),(2,'user','Utilisateur standard','2020-07-23 11:54:28','2020-07-23 11:54:28');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `secretaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secretaires` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `secretaires_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `secretaires` WRITE;
/*!40000 ALTER TABLE `secretaires` DISABLE KEYS */;
INSERT INTO `secretaires` VALUES (1,'Ben Attou','Safae','rue artan 58 1030 schaerbeek','0452658578','safaeSec@gmail.com','$2y$10$9bOP5q.YF1FF0G66cdLqGu070Qajx/1UnEzv0T2937gSIrUQ/VXmG','actif','2020-07-23 12:04:48','2020-07-23 12:04:48');
/*!40000 ALTER TABLE `secretaires` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'site.title','Title du site','Title du site','','text',1,'Site'),(2,'site.description','Description du site','Description du site','','text',2,'Site'),(3,'site.logo','Logo du site','','','image',3,'Site'),(4,'site.google_analytics_tracking_id','Google Analytics ID de Tracking','','','text',4,'Site'),(5,'admin.bg_image','Image de fond de l\'espace admin','','','image',5,'Admin'),(6,'admin.title','Titre de l\'espace admin','Voyager','','text',1,'Admin'),(7,'admin.description','Description de l\'espace admin','Bienvenue dans Voyager, le panneau d\'administration qui manquait à Laravel.','','text',2,'Admin'),(8,'admin.loader','Chargement de l\'espace admin','','','image',3,'Admin'),(9,'admin.icon_image','Icône de l\'espace admin','','','image',4,'Admin'),(10,'admin.google_analytics_client_id','Google Analytics ID Client (Utilisé pour le panneau d\'administration)','','','text',1,'Admin');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_roles_user_id_index` (`user_id`),
  KEY `user_roles_role_id_index` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

