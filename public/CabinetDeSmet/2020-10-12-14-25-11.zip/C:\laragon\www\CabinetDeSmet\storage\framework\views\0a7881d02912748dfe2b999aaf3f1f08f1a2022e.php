<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e('Facteur risque de : '.' '.$facteur->dossierMed->patient->prenom); ?></div>
                
               
                <div class="card-body">
                        <div class="form-group mt-2 ">
                            <label class="form-label ml-3">Description</label>

                            <div class="col-md-12">
                                <textarea class="form-control w-100" rows="5"><?php echo e($facteur->description); ?></textarea>

                               
                            </div>
                        </div>  


                        <div class="form-group mt-2 ">
                            <label class="form-label ml-3">Date</label>

                            <div class="col-md-12">
                                <textarea class="form-control w-100" rows="1"><?php echo e($facteur->created_at->format('d-m-Y H:i:s')); ?></textarea>

                               
                            </div>
                        </div>  

                        <div class="form-group mt-2 ">
                            <label class="form-label ml-3">Inami médecin</label>

                            <div class="col-md-12">
                                <textarea class="form-control w-100" rows="1"><?php echo e($facteur->inami_med); ?></textarea>

                               
                            </div>
                        </div>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/facteur/voirFact.blade.php ENDPATH**/ ?>