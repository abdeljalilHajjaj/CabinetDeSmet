<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('Drop-Down-Combo-Tree/style.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Formulaire d\'ajout d\'une ordonnance')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('ajouter.ord')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id_patient" value="<?php echo e($patient); ?>">
                        

                       

                        <div class="form-group row">
                            <label for="saturation_oxygene" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Liste de médicaments')); ?></label>

                            <div class="col-md-6">
                            <input type="text" name="list[]" id="example" class="form-control" placeholder="Choix" autocomplete="off" >

                               
                            </div>
                        </div>


                       


                                

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Crée une ordonnance
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    var myData = [

    <?php $__currentLoopData = $medicaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            id:<?php echo e($medicament->id); ?>,
            title: '<?php echo e($medicament->nomMedic); ?> '+': '+'<?php echo e($medicament->posologie); ?> '
        },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
   
];

$('#example').comboTree({
  source : myData,
  isMultiple: true
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/ordonnance/ajouterOrd.blade.php ENDPATH**/ ?>