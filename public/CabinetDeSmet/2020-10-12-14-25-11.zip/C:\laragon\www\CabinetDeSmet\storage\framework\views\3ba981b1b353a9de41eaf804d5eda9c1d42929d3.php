<?php $__env->startSection('content'); ?>
    <div style="width: 100vw;float: right;"id="calendar"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>

    document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        googleCalendarApiKey: 'AIzaSyA6SssjS-N1lN2FqOZaZgSeg8lreQmGgoQ',
        locale: 'fr',
        plugins: [ 'dayGrid','timeGrid','googleCalendar' ],
        defaultView: 'timeGridWeek',
        allDaySlot: false,
        hiddenDays: [ 0, 6 ],
        minTime: "09:00:00",
        maxTime:"18:00:00",
        header:{
        left:   'title dayGrid timeGrid timeGridWeek',
            center: '',
            right:  'today prev,next'
        },
        height: 400,
        
        

        events: {
            googleCalendarId: "<?php echo e(Auth::guard('medecin')->user()->gCal_id); ?>",
            className: 'nice-event',
            color:'green',

        },
    });

    calendar.render();
    });


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/agenda.blade.php ENDPATH**/ ?>