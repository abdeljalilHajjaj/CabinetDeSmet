<?php $__env->startSection('content'); ?>

<h1 class="text-center mb-5">Historique des rendez-vous</h1>
<div class="table-responsive w-100 mt-2 float-right">
<table class="table table-striped" id="table">
        <thead>
            <th>Date et heure du rendez-vous</th>
            <th> Nom du patient</th>
            <th> Numéro de registre national</th>
            <th>Medecin</th>
            <th>Statut</th>
            
        </thead>

        <tbody>
            <?php $__currentLoopData = $rdvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rdv->dateFormat()); ?></td>
                    <td><?php echo e($rdv->patient->nom); ?></td>
                    <td><?php echo e($rdv->patient->rn); ?></td>
                    <td>Dr. <?php echo e($rdv->medecin->nom); ?></td>
                    <td><?php echo e($rdv->statut); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready( function () {
            $('#table').DataTable({
                "language": {
                        "url": "<?php echo e(asset('frDataTables.txt')); ?> "

                },
                "order": [[ 0, "desc" ]]
            });

       
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secretaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/secretaire/secPatient/historiqueRdv.blade.php ENDPATH**/ ?>