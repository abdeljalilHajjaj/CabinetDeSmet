<?php $__env->startSection('content'); ?>
    
        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>

        <?php if(session()->has('erreur')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('erreur')); ?>

            </div>
        <?php endif; ?>


        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.patient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/patient/index.blade.php ENDPATH**/ ?>