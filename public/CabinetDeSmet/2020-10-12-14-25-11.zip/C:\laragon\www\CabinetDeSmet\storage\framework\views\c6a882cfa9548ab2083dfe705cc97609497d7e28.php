<html lang="fr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <h2>Annulation de votre rendez-vous</h2>
    <?php if($data['sexe'] == 'H'): ?>
    <p>Bonjour Monsieur <?php echo e($data['nom']); ?> </p>
    <?php endif; ?>
    <?php if($data['sexe'] == 'F'): ?>
    <p>Bonjour Madame <?php echo e($data['nom']); ?> </p>
    <?php endif; ?>
    
    <br>
    <p>Votre rendez-vous du <strong><?php echo e($data['dateRdv']); ?> </strong> a été annulé </p>
    <br>

    <p>Récapitulatif de votre rendez-vous :</p>
    <br>
    <ul>
      <li><strong>date et heure du rendez-vous</strong><?php echo e($data['dateRdv']); ?></li>
      <li><strong>Nom du médecin</strong> :Dr . <?php echo e($data['medecin']); ?></li>
      <li><strong>Lieu du rendez-vous</strong>: Rue des trois gardes 344 schaerbeek </li>
    </ul>
    
      

     
    
   
  </body>
</html><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/emails/annulationRdv.blade.php ENDPATH**/ ?>