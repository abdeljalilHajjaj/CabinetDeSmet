<?php $__env->startSection('content'); ?>
    <h1 class="text-center mb-5">Liste des patients en attente</h1>
    <div class="table table-responsive w-100 float-right">
        <table class="table table-striped" id="table">
            <thead>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Numéro de registre national</th>
                <th>Adresse</th>
                <th>Tel</th>
                <th>date d'inscription</th>
                <th></th>
            </thead>

            <tbody>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($patient->nom); ?> </td>
                        <td><?php echo e($patient->prenom); ?> </td>
                        <td><?php echo e($patient->rn); ?></td>
                        <td><?php echo e($patient->adresse); ?></td>
                        <td><?php echo e($patient->tel); ?></td>
                        <td><?php echo e($patient->created_at->format('d/m/Y H:i')); ?> </td>
                        <td>

                            <a href="<?php echo e(route('sec.confirmer.inscription',['id'=>$patient->id ])); ?> "><button>Confirmer l'inscription </button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        $('#table').DataTable({
            "language": {
                    "url": "<?php echo e(asset('frDataTables.txt')); ?> "
             }
        });

       
    } );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secretaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/secretaire/secPatient/listeAttentePatient.blade.php ENDPATH**/ ?>