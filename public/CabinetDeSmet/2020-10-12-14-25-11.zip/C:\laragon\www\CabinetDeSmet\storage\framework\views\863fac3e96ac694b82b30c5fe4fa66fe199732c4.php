<?php $__env->startSection('content'); ?>
<div class="table-responsive w-100 float-right">
            <table class="table" id="table">
                <thead>
                    <th>Date et heure du rendez-vous</th>
                    <th>Date de prise du rendez-vous</th>
                    <th>Medecin</th>
                    <th>Lieu</th>
                    
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = Auth::guard('patient')->user()->rdv->where('statut','!=','actif'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr>
                            <td><?php echo e($rdv->dateFormat()); ?> </td>
                            <td><?php echo e($rdv->created_at->format('d/m/Y H:i')); ?> </td>
                            <td>Dr <?php echo e($rdv->medecin->nom); ?> </td>
                            <td>Rue des trois gardes 344 schaerbeek</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            
            </table>
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
         $(document).ready( function () {
            $('#table').DataTable({
                "language": {
                        "url": "<?php echo e(asset('frDataTables.txt')); ?> "
                }
            });

        
        } );
    

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.patient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/patient/rdvPatient/historiqueRdv.blade.php ENDPATH**/ ?>