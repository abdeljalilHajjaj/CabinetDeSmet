<?php $__env->startSection('content'); ?>

        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Ajouter un nouveau rendez-vous</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('med.cree.rdv')); ?>">
                            <?php echo csrf_field(); ?>



                            <div class="form-group row">
                                <label for="rn" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Numéro de registre national')); ?></label>

                                <div class="col-md-6">
                                <input list="test" name="rn">
                                   <datalist  id="test">
                                       <?php $__currentLoopData = $patients->where('statut','actif'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($patient->rn); ?>"> <?php echo e($patient->nom); ?> : <?php echo e($patient->rn); ?> </option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </datalist>

                                    <?php $__errorArgs = ['rn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            


                            <div class="form-group row">
                                <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date du rendez-vous')); ?></label>
                                <div class="col-md-6">
                                    <input type="text" name="date" value="choisir date" id="available_date" data-date-format="yyyy-mm-dd"> 
                                </div>
                                 <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="form-group row">
                                <label for="adresse" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Heure du rendez-vous')); ?></label>
                                <div class="col-md-6">
                                <select id='available_times' name="heure">

                                </select>
                                </div>
                                
                            </div>



                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" id="submit" class="btn btn-primary">
                                        Ajouter
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
           
              $(document).ready(function() {
               

                    $('#available_date').datepicker({
                        format: 'dd-mm-yyyy',
                        language: 'fr',
                        daysOfWeekDisabled: [0,6],
                        startDate:"<?php echo e(date('d-m-Y')); ?>",
                        endDate: "<?php echo e($date->format('d-m-Y')); ?> "
                    });
                    $('#available_date').on('change', function() { 
                        var date = $('#available_date').val();
                        
                        $.post({
                            type: "POST",
                            url: "<?php echo e(route('med.heureDispo')); ?>",
                            data:{'date':date},
                            
                            success:function(data){
                               
                                if($.isEmptyObject(data)){
                                    document.getElementById('submit').disabled = true;
                                    document.getElementById('available_times').innerHTML = 	'<option value="">Pas d\'heure disponible</option>';
                                
                                }
                                if(!$.isEmptyObject(data)){
                                    document.getElementById('submit').disabled = false;
                                    document.getElementById('available_times').innerHTML = data;
                                }
                            },
                            fail:function(data){
                                console.log(data);
                            }
                        });


                    });
                    $('#medecin').on('change', function(){
                        var date = $('#available_date').val();
                      
                        $.post({
                            type: "POST",
                            url: "<?php echo e(route('med.heureDispo')); ?>",
                            data:{'date':date},
                            
                            success:function(data){

                                if($.isEmptyObject(data)){
                                    document.getElementById('submit').disabled = true;
                                    document.getElementById('available_times').innerHTML = 	'<option value="">Pas d\'heure disponible</option>';
                                
                                }
                                if(!$.isEmptyObject(data)){
                                    document.getElementById('submit').disabled = false;
                                    document.getElementById('available_times').innerHTML = data;
                                }
                            },
                            fail:function(data){
                                console.log(data);
                            }
                        });
                    });

                        


                  });

				  
                   

                
			
  

             
          </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/medCreeRdv.blade.php ENDPATH**/ ?>