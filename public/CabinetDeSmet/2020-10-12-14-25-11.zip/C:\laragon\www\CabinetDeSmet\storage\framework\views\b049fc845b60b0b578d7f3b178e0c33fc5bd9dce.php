<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="w-100 float-right" id='calendar'></div>
    </div>
   
<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>
<script>
function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');

  var calendar = new FullCalendar.Calendar(calendarEl, {
    googleCalendarApiKey: 'AIzaSyA6SssjS-N1lN2FqOZaZgSeg8lreQmGgoQ',
    schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives',
    locale:'fr',
    plugins: [ 'googleCalendar','resourceTimeline'],
    defaultView: 'resourceTimeline',
    minTime: "09:00:00",
    maxTime:"18:00:00",
    aspectRatio: 2,
    resourceAreaWidth:'10%',
    slotWidth:150,
    slotHeight:150,
 
    height: 400,
    resources: [
        <?php $__currentLoopData = $medecin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                id:"<?php echo e($med->nom); ?>",
                title:"<?php echo e($med->nom); ?>",
                eventBackgroundColor:getRandomColor(),
                
            },
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ],
  eventSources:[ 
    <?php $__currentLoopData = $medecin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            googleCalendarId:"<?php echo e($med->gCal_id); ?>",
            
            eventDataTransform: function(event){
            event.resourceId = "<?php echo e($med->nom); ?>";
            return event;
            }
           

        },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
  ]
  });

  calendar.render();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secretaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/secretaire/secAgenda.blade.php ENDPATH**/ ?>