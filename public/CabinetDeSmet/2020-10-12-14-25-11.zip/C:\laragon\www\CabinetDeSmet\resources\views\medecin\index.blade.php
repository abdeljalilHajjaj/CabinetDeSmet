@extends('layouts.medecin')

@section('content')

	
@endsection