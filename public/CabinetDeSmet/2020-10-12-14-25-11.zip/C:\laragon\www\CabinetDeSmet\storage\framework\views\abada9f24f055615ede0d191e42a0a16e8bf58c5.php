<html lang="fr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <h2>Confirmation de votre  Rendez-vous</h2>
    
    <?php if($sexe == "H"): ?>
        Bonjour Monsieur <?php echo e($nom); ?>,
    <?php endif; ?>

    <?php if($sexe == "F"): ?>
        Bonjour Madame <?php echo e($nom); ?>,
    <?php endif; ?>
    <p>Voici un récapitulatif de votre rendez-vous à venir : </p>

    <br>
    <ul>
      <li><strong>Date et heure du rendez-vous</strong> : <?php echo e($dateRdv); ?></li>
      <li><strong>Nom du médecin</strong> :Dr . <?php echo e($medecin); ?></li>
      <li><strong>Lieu du rendez-vous</strong>: Rue des trois gardes 344 schaerbeek </li>

     
    
    </ul>
  </body>
</html><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/recapRdv.blade.php ENDPATH**/ ?>