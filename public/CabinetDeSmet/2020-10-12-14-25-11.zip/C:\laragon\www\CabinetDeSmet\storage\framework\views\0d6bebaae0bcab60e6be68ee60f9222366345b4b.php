<?php $__env->startSection('content'); ?>

        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>

    <div class="table table-responsive w-100  h-75 float-right">
        <div class="mb-3"><a  href="<?php echo e(route('med.form.dispo')); ?> "> <button class="btn-sm btn-primary">Ajouter un événement</button> </a></div> 
        <table class="table" id="myTable">
            <thead>
                <th>Détails</th>
                <th>Date de debut</th>
                <th>Date de fin</th>
                <th></th>
            </thead>

            <tbody>
                <?php $__currentLoopData = Auth::guard('medecin')->user()->disponibilite->where('statut','actif'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($dispo->details); ?></td>
                            <td><?php echo e($dispo->dateFormat()); ?></td>
                            <td><?php echo e($dispo->dateFinFormat()); ?></td>
                            <td>
                                <a href="<?php echo e(route('med.supp.dispo',['id'=>$dispo->id])); ?> "><button class="btn btn-danger"><i class="fas fa-trash"></i> </button></a>
                               
                            </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
$(document).ready( function () {
    $('#myTable').DataTable({
        "language": {
            "url": "<?php echo e(asset('frDataTables.txt')); ?> "
        }
    });
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medecin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/medecin/disponibilite/listeDispo.blade.php ENDPATH**/ ?>