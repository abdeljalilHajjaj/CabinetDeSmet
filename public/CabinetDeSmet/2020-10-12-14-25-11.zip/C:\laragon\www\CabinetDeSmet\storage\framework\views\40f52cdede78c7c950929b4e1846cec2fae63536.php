<?php $__env->startSection('content'); ?>
        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.secretaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/secretaire/index.blade.php ENDPATH**/ ?>