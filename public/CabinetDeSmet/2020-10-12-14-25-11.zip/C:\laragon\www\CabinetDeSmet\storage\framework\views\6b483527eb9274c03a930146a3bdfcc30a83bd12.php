<html lang="fr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <h2>Confirmation de votre  Rendez-vous</h2>
    
    <?php if($data['sexe'] == "H"): ?>
        Bonjour Monsieur <?php echo e($data['nom']); ?>,
    <?php endif; ?>

    <?php if($data['sexe'] == "F"): ?>
        Bonjour Madame <?php echo e($data['nom']); ?>,
    <?php endif; ?>

    <ul>
      <li><strong>Date et heure du rendez-vous</strong> : <?php echo e($data['dateRdv']); ?></li>
      <li><strong>Nom du médecin</strong> :Dr . <?php echo e($data['medecin']); ?></li>
      <li><strong>Lieu du rendez-vous</strong>: Rue des trois gardes 344 schaerbeek </li>

     
    
    </ul>
  </body>
</html><?php /**PATH C:\laragon\www\CabinetDeSmet\resources\views/emails/ConfirmationRdv.blade.php ENDPATH**/ ?>